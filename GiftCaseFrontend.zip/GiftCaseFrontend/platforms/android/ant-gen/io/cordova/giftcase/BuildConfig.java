/** Automatically generated file. DO NOT MODIFY */
package io.cordova.giftcase;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}