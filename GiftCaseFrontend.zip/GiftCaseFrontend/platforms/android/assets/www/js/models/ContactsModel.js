define(function(require) {

	var Backbone = require("backbone");

	var ContactsModel = Backbone.Model.extend({
		constructorName: "ContactsModel"
	});

	return ContactsModel;
});