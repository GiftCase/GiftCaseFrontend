define(function(require) {

  var Backbone = require("backbone");
  var ContactsModel = require("models/ContactsModel");
  //var ContactView = require("models/ContactView");
  var Utils = require("utils");

  var ContactsView = Utils.Page.extend({

    constructorName: "ContactsView",

    model: ContactsModel,

    initialize: function() {
      this.template = Utils.templates.contactsList;

      this.contacts= new ContactsModel();
      this.contacts.on("showContacts", this.showContacts, this );
      //this.contacts.on("error", this.errorHandler, this);
    },

    id: "contacts",
    className: "i-g page",
    
    /*errorHandler: function(){
      $('#error').append("The events could not be loaded.");
      document.getElementById("error").style.visibility="visible";
      document.getElementById("error").style.display="initial";
    },*/

    showContacts: function(result){

      var listContacts = new Array();
      for (var i = 0; i < result.length; i++) {
            listContacts[i] = new ContactView({
              model: result[i]
              }).render().el;
        }
        
        $('#contactsList').append(listContacts);
    },
  
    render: function() {
      $(this.el).html(this.template); 
      return this;
    }

  });

  return ContactsView;

});