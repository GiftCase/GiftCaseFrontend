define(['facebook'], function(FB) {

	var FacebookHelper = {
		
		facebookLoginToken: "notinitialized",
		facebookId: "notinitialized",
		facebookPemissions: ["public_profile", "email", "friend", "user_likes", "user_friends", 
		    "user_actions.books", "user_actions.music", "user_actions.news", "user_actions.video",
		    "user_activities", "user_birthday", "user_events", "user_games_activity", "user_hometown",
		    "user_interests", "user_likes", "user_location"],
		declinedFacebookPemissions:[],
		success: "success",
		permissions: "permissions",
		notlogged: "notlogged",

		initialize: function()
		{
			document.getElementById('mrunnnnn').innerHTML = "Facebook initializes " + document.getElementById('mrunnnnn').innerHTML;
			document.getElementById('mrunnnnn').innerHTML = FB.api + " " + document.getElementById('mrunnnnn').innerHTML;
			FB.init({
			  appId      : '878246272199421',
			  xfbml      : true,
              version    : 'v2.1'
			});
			console.log("Facebook initialized");
			document.getElementById('mrunnnnn').innerHTML = "Facebook initialized " + document.getElementById('mrunnnnn').innerHTML;
		},

	    extractUserData: function(response) {
	      document.getElementById('mrunnnnn').innerHTML = "Welcome!  Fetching your information....  " + document.getElementById('mrunnnnn').innerHTML;
	      this.facebookLoginToken = response.authResponse.accessToken;
	      this.facebookLoginToken = response.authResponse.userID;
	    },

	    checkUserLoggedInStatus: function()
	    {
	    	var loggedIn = this.notlogged;
	    	document.getElementById('mrunnnnn').innerHTML = "Check user login status " + document.getElementById('mrunnnnn').innerHTML;
		 
	    	FB.getLoginStatus(function(response) {
		        if (response.status === 'connected') 
		        {
		          document.getElementById('mrunnnnn').innerHTML = "Logged in " + document.getElementById('mrunnnnn').innerHTML;
		
		          extractUserData(respose);

		          var grantedPermissions;
		          FB.api('/me/permissions', function(response) {
		          	document.getElementById('mrunnnnn').innerHTML = "Permissions granted " + document.getElementById('mrunnnnn').innerHTML;
					document.getElementById('mrunnnnn').innerHTML = JSON.stringify(response) + " " + document.getElementById('mrunnnnn').innerHTML;

					grantedPermissions = $.parseJSON(JSON.stringify(response));
				  });

		    	  var checkAllPermissions = true;

		    	  for (var i = 0; i < facebookPemissions.length; i++)
		    	  {
		    	  	var found = false;
		    	  	for (var j = 0; j < grantedPermissions.length; j++)
		    	    {
		    	  		if (grantedPermissions[j].permission === facebookPemissions[i])
		    	  		{
		    	  			found= true;
		    	  			if (grantedPermissions[j] !== "granted")
		    	  			{
		    	  				declinedFacebookPemissions.add(grantedPermissions[j].permission);
		    	  				checkAllPermissions = false;
		    	  			}
		    	  		}
		    	    }
		    	    if (!found)
		    	    {
		    	    	declinedFacebookPemissions.add(facebookPemissions[i]);
		    	    }
		    	  }

		    	  if (checkAllPermissions)
		    	  {
		    	  	 document.getElementById('mrunnnnn').innerHTML = "All permissions granted " + document.getElementById('mrunnnnn').innerHTML;

			    	 loggedIn = this.success;
			      }
			      else
			      {
			      	 loggedIn = this.permissions;
			      	 document.getElementById('mrunnnnn').innerHTML = "Not all permissions granted " + document.getElementById('mrunnnnn').innerHTML;

			      }
		        }
		        else {
		          loggedIn = this.notlogged;
		          document.getElementById('mrunnnnn').innerHTML = "Not logged in. " + document.getElementById('mrunnnnn').innerHTML;
		        }
		    });
		    return loggedIn;
	    },

	    logout: function()
	    {
	    	FB.logout(function(response) {
	    		document.getElementById('mrunnnnn').innerHTML = "Person logged out " + document.getElementById('mrunnnnn').innerHTML;
	      	});
	    },

	    login: function()
	    {
	    	var self = this;
	    	document.getElementById('mrunnnnn').innerHTML = "Facebook permissions " +
	    	this.facebookPemissions.join() + " " + document.getElementById('mrunnnnn').innerHTML;
	    	document.getElementById('mrunnnnn').innerHTML = "Declines permissions " +
	    	this.declinedFacebookPemissions.join() + " " + document.getElementById('mrunnnnn').innerHTML;
	        	
	    	var status = this.notlogged;
	    	if (this.declinedFacebookPemissions.length != 0)
	    	{
	    		FB.login(function(response){
		    		status = self.checkUserLoggedInStatus();
		    	}, {scope: this.declinedFacebookPemissions.join(), auth_type: 'rerequest'});
	    	}
	    	else
	    	{
		    	FB.login(function(response){
			    	status = self.checkUserLoggedInStatus();
			    }, {scope: this.facebookPemissions.join()});
	    	}
			return status;
	    }
  	};

	return FacebookHelper;
});