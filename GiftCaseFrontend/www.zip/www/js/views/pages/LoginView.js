define(function(require) {

  var Backbone = require("backbone");
  var Utils = require("utils");
  var FacebookHelper = require("helpers/FacebookHelper");

  var LoginView = Utils.Page.extend({

    constructorName: "LoginView",

    loginError: "",

    events: {
      "touchend #facebookLoginButton": "facebookLogin"
    },

    initialize: function() {
      this.template = Utils.templates.loginview;
    },

    render: function() {
      var $newEl = $(this.template());

      if (this.$el[0].tagName !== $newEl[0].tagName || 
          this.$el[0].className !== $newEl[0].className || 
          this.$el[0].id !== $newEl[0].id) {
        this.setElement($newEl);
      }

      this.$el.html($newEl.html());
      console.log(this.$el.find("#loginError"));
      this.$el.find("#loginError").innerHTML = this.loginError;
      return this;
    },

    facebookLogin: function(e) {
      document.getElementById("facebookLoginButton").src = "img/facebook-login-button.png";
      var result = FacebookHelper.login();
      if (result === FacebookHelper.success)
      {
        Backbone.history.navigate("showstructure", {
          trigger: true
        });
      }
      else if (result === FacebookHelper.permissions)
      {
        console.log("Permissions not granted");
        this.loginError = "Error in granted permissions. Please try to log in again.";
        document.getElementById("loginError").innerHTML = this.loginError;
      }
      else if (result === FacebookHelper.notlogged)
      {
        console.log("User not logged in");
        this.loginError = "Error while logging in. Please try to log in again.";
        document.getElementById("loginError").innerHTML = this.loginError;
      }
    },

    showPermissionsError: function()
    {
      loginError = "Error in granted permissions. Please try to log in again.";
      document.getElementById("loginError").innerHTML = loginError;
    }
  });

  return LoginView;

});